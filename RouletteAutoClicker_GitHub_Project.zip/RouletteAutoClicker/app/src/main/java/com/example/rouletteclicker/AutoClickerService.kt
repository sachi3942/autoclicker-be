package com.example.rouletteclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class AutoClickerService : AccessibilityService() {

    companion object {
        var instance: AutoClickerService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    fun performClickAt(x: Float, y: Float, isDoubleTap: Boolean) {
        val builder = GestureDescription.Builder()
        val path = Path().apply { moveTo(x, y) }

        if (isDoubleTap) {
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            builder.addStroke(GestureDescription.StrokeDescription(path, 150, 50))
        } else {
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
        }

        dispatchGesture(builder.build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
